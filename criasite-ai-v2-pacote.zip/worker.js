const ALLOWED_ORIGIN = "https://angelalves-dev.github.io";
const MODEL = "gemini-2.5-flash";

function corsHeaders(origin) {
  return {
    "Access-Control-Allow-Origin": origin === ALLOWED_ORIGIN ? ALLOWED_ORIGIN : ALLOWED_ORIGIN,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Vary": "Origin"
  };
}
function json(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...corsHeaders(origin) }
  });
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders(origin) });
    }
    if (request.method !== "POST") return json({ error: "Use POST para gerar um site." }, 405, origin);
    if (origin !== ALLOWED_ORIGIN) return json({ error: "Origem não autorizada." }, 403, origin);
    if (!env.GEMINI_API_KEY) return json({ error: "A chave de IA ainda não foi configurada no Worker." }, 503, origin);

    let body;
    try { body = await request.json(); }
    catch { return json({ error: "Envie uma descrição válida em JSON." }, 400, origin); }
    const prompt = String(body.prompt || "").trim();
    if (prompt.length < 15 || prompt.length > 1800) {
      return json({ error: "A descrição deve ter entre 15 e 1800 caracteres." }, 400, origin);
    }
    const business = body.business && typeof body.business === "object" ? body.business : {};
    const businessName = String(business.name || "Meu Negócio").slice(0, 70);
    const type = String(business.type || "serviços").slice(0, 50);
    const accent = /^#[0-9a-fA-F]{6}$/.test(String(business.accent || "")) ? business.accent : "#7c3aed";

    const instruction = `Você é um desenvolvedor front-end experiente. Gere um site completo, bonito, responsivo e acessível em um único arquivo HTML em português brasileiro. Responda SOMENTE com o HTML bruto, começando por <!DOCTYPE html>, sem Markdown nem explicações. Use CSS dentro de <style>, sem bibliotecas externas, sem dependências de build e sem imagens remotas obrigatórias. Não inclua JavaScript, scripts, iframes, formulários que enviem dados, rastreadores ou código de terceiros. Use links de contato seguros e texto de demonstração realista, sem inventar endereço, depoimentos, certificações ou promessas. Inclua cabeçalho, hero, serviços/produtos, diferenciais, chamada para ação, seção de contato e rodapé. Design profissional, mobile-first, bom contraste, sem exageros. Nome do negócio: ${businessName}. Categoria: ${type}. Cor principal: ${accent}. Pedido do usuário: ${prompt}`;

    try {
      const apiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${env.GEMINI_API_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: instruction }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: 8192 }
        })
      });
      const data = await apiResponse.json();
      if (!apiResponse.ok) {
        const message = data?.error?.message || "O provedor de IA recusou a solicitação.";
        return json({ error: `Falha na API de IA: ${message}` }, 502, origin);
      }
      let html = (data?.candidates?.[0]?.content?.parts || []).map(part => part.text || "").join("").trim();
      html = html.replace(/^```(?:html)?\s*/i, "").replace(/\s*```$/, "").trim();
      if (!/^<!doctype html/i.test(html) || !/<html[\s>]/i.test(html)) {
        return json({ error: "A IA não devolveu HTML válido. Tente novamente com uma descrição mais simples." }, 502, origin);
      }
      // Remove scripts e elementos perigosos antes de entregar o arquivo gerado.
      html = html
        .replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, "")
        .replace(/<iframe\b[^>]*>[\s\S]*?<\/iframe\s*>/gi, "")
        .replace(/<(?:object|embed)\b[^>]*>[\s\S]*?<\/(?:object|embed)\s*>/gi, "")
        .replace(/\s+on[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "")
        .replace(/javascript\s*:/gi, "");
      // Não é uma solução antiabuso completa; limita o tamanho da resposta para reduzir consumo inesperado.
      if (html.length > 100000) return json({ error: "O site gerado ficou muito grande. Tente uma descrição mais curta." }, 502, origin);
      return json({ html }, 200, origin);
    } catch {
      return json({ error: "Não foi possível conectar ao serviço de IA. Tente novamente." }, 502, origin);
    }
  }
};
